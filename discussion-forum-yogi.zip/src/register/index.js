import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { asyncRegisterUsers } from './RegisterAction'
import RegsisterFormComponent from './RegsisterFormComponent'

const Register = () => {
    const [input, setInput] = useState({
        name: "",
        email: "",
        password: ""
    })
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const handleRegister = async (e) => {
        e.preventDefault()
        dispatch(asyncRegisterUsers(input))
        navigate('/login')
    }

    const handleChange = (e) => setInput({ ...input, [e.target.name]: e.target.value })

    return (
        <div className='flex items-center justify-center h-screen layer-main sub-title'>
            <div className="w-full px-4 mx-auto lg:w-1/2">
                <div className="md:p-12 md:mx-6">
                    <RegsisterFormComponent registerAction={handleRegister} stateInput={input} changeAction={handleChange} />
                </div>
            </div>
        </div>
    )
}

export default Register
