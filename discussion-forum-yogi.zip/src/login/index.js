import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { asyncSetAuthUser } from './LoginAction'
import LoginFormComponent from './LoginFormComponent'

const Login = () => {
  const [input, setInput] = useState({
    email: "",
    password: ""
  })
  const dispatch = useDispatch()

  const handleLogin = async (e) => {
    e.preventDefault()
    dispatch(asyncSetAuthUser(input))
  }
  const handleChange = (e) => setInput({ ...input, [e.target.name]: e.target.value })

  return (
    <div className='flex items-center justify-center h-screen layer-main sub-title'>
      <div className="w-full px-4 mx-auto lg:w-1/2">
        <div className="md:p-12 md:mx-6">
          {/* Login */}
          <LoginFormComponent loginAction={handleLogin} stateInput={input} changeAction={handleChange} />
        </div>
      </div>
    </div>
  )
}

export default Login
